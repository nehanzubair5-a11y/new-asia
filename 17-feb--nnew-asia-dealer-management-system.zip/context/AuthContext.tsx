import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { User, AuthContextType } from '../types.ts';
import { MOCK_DEALERS } from '../constants.ts';

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [user, setUser] = useState<User | null>(null);

    useEffect(() => {
        try {
            const storedUser = localStorage.getItem('user');
            if (storedUser) {
                setUser(JSON.parse(storedUser));
            }
        } catch (error) {
            console.error("Failed to parse user from localStorage", error);
            localStorage.removeItem('user');
        }
    }, []);

    const login = (email: string, role: string): User => {
        // This is a simulation. In a real app, you'd call an API.
        let userData: User = {
            _id: `user-${Date.now()}`,
            email: email,
            name: 'Demo User',
            role: role,
        };
        if (role === 'Dealer') {
            userData.name = MOCK_DEALERS[0].ownerName;
            userData.dealerId = MOCK_DEALERS[0]._id; // Assign first dealer for demo
        }
        if (role === 'Admin') {
             userData.name = "Admin User";
        }
        if (role === 'Super Admin') {
             userData.name = "Super Admin";
        }
        if (role === 'Product Manager') {
            userData.name = "Product Manager";
        }
        if (role === 'Booking Manager') {
            userData.name = "Booking Manager";
        }
        if (role === 'Stock Controller') {
            userData.name = "Stock Controller";
        }
        if (role === 'Finance / Auditor') {
             userData.name = "Finance Auditor";
        }
        if (role === 'Logistics') {
             userData.name = "Logistics Staff";
        }
        setUser(userData);
        localStorage.setItem('user', JSON.stringify(userData));
        return userData;
    };

    const logout = () => {
        setUser(null);
        localStorage.removeItem('user');
    };

    const updateCurrentUser = (updatedUser: User) => {
        setUser(updatedUser);
        localStorage.setItem('user', JSON.stringify(updatedUser));
    };

    return (
        <AuthContext.Provider value={{ isAuthenticated: !!user, user, login, logout, updateCurrentUser }}>
            {children}
        </AuthContext.Provider>
    );
};