import {
    MOCK_DEALERS, MOCK_PRODUCTS, MOCK_STOCK, MOCK_STOCK_ORDERS, MOCK_BOOKINGS, MOCK_USERS, MOCK_DEALER_PAYMENTS, MOCK_ANNOUNCEMENTS, MOCK_ANNOUNCEMENT_RECIPIENTS, MOCK_CONVERSATIONS, MOCK_MESSAGES
} from '../constants.ts';
import { Dealer, Product, StockItem, StockOrder, Booking, StockStatus, User, OrderStatus, Role, DealerPayment, Announcement, AnnouncementRecipient, Conversation, Message } from '../types.ts';
import { ALL_PERMISSIONS } from '../permissions.ts';

// Simulate network delay
const FAKE_DELAY = 400;

const DEFAULT_ROLES: Role[] = [
  { _id: 'role-super', name: 'Super Admin', permissions: ALL_PERMISSIONS, isEditable: false },
  { _id: 'role-admin', name: 'Admin', permissions: ALL_PERMISSIONS.filter(p => p !== 'system:manage_settings'), isEditable: true },
  { _id: 'role-dealer', name: 'Dealer', permissions: ['dealer_self:manage_bookings', 'dealer_self:create_order', 'dealer_self:confirm_receipt'], isEditable: false },
  { _id: 'role-pm', name: 'Product Manager', permissions: ['product:update_core', 'product:manage_variants'], isEditable: true },
  { _id: 'role-bm', name: 'Booking Manager', permissions: ['booking:create', 'booking:update'], isEditable: true },
  { _id: 'role-sc', name: 'Stock Controller', permissions: ['order:approve'], isEditable: true },
  { _id: 'role-auditor', name: 'Finance / Auditor', permissions: ['booking:view_invoice', 'system:view_reports', 'system:view_audit_logs', 'system:view_commission_reports', 'system:view_finance_ledger'], isEditable: true },
  { _id: 'role-logistics', name: 'Logistics', permissions: ['order:dispatch'], isEditable: true },
];

// A simple in-memory store to simulate a backend database
let usersDB = [...MOCK_USERS];
let rolesDB = [...DEFAULT_ROLES];
let dealersDB = [...MOCK_DEALERS];
let productsDB = [...MOCK_PRODUCTS];
let stockDB = [...MOCK_STOCK];
let stockOrdersDB = [...MOCK_STOCK_ORDERS];
let bookingsDB = [...MOCK_BOOKINGS];
let dealerPaymentsDB = [...MOCK_DEALER_PAYMENTS];
let announcementsDB = [...MOCK_ANNOUNCEMENTS];
let announcementRecipientsDB = [...MOCK_ANNOUNCEMENT_RECIPIENTS];
let conversationsDB = [...MOCK_CONVERSATIONS];
let messagesDB = [...MOCK_MESSAGES];


const createApiFunction = <T,>(data: T) => {
    return () => new Promise<T>(resolve => {
        setTimeout(() => resolve(JSON.parse(JSON.stringify(data))), FAKE_DELAY);
    });
};

const createSaveFunction = <T extends { _id: string }>(db: T[]) => {
    return (item: T) => new Promise<T>(resolve => {
        setTimeout(() => {
            const index = db.findIndex(i => i._id === item._id);
            if (index > -1) {
                db[index] = item; // Update
            } else {
                db.push(item); // Create
            }
            resolve(JSON.parse(JSON.stringify(item)));
        }, FAKE_DELAY);
    });
};

export const api = {
    // Fetch Functions
    fetchUsers: createApiFunction(usersDB),
    fetchRoles: createApiFunction(rolesDB),
    fetchDealers: createApiFunction(dealersDB),
    fetchProducts: createApiFunction(productsDB),
    fetchStock: createApiFunction(stockDB),
    fetchStockOrders: createApiFunction(stockOrdersDB),
    fetchBookings: createApiFunction(bookingsDB),
    fetchDealerPayments: createApiFunction(dealerPaymentsDB),
    fetchAnnouncements: createApiFunction(announcementsDB),
    fetchAnnouncementRecipients: createApiFunction(announcementRecipientsDB),
    fetchConversations: createApiFunction(conversationsDB),
    fetchMessages: createApiFunction(messagesDB),

    // Mutation Functions (simulating create/update)
    saveUser: createSaveFunction(usersDB),
    saveRole: createSaveFunction(rolesDB),
    saveDealer: createSaveFunction(dealersDB),
    saveProduct: createSaveFunction(productsDB),
    saveStockItem: createSaveFunction(stockDB),
    saveStockOrder: createSaveFunction(stockOrdersDB),
    saveBooking: createSaveFunction(bookingsDB),
    saveDealerPayment: createSaveFunction(dealerPaymentsDB),
    saveAnnouncement: createSaveFunction(announcementsDB),
    saveAnnouncementRecipient: createSaveFunction(announcementRecipientsDB),
    saveConversation: createSaveFunction(conversationsDB),
    saveMessage: createSaveFunction(messagesDB),

    deleteUser: (userId: string) => new Promise<void>(resolve => {
        setTimeout(() => {
            usersDB = usersDB.filter(u => u._id !== userId);
            resolve();
        }, FAKE_DELAY);
    }),

    // More complex operations can be mocked as well
    saveBulkStockStatus: (stockIds: string[], status: any) => new Promise<StockItem[]>(resolve => {
        setTimeout(() => {
            const updatedItems: StockItem[] = [];
            stockDB = stockDB.map(item => {
                if (stockIds.includes(item._id)) {
                    const updated = { ...item, status };
                    updatedItems.push(updated);
                    return updated;
                }
                return item;
            });
            resolve(JSON.parse(JSON.stringify(updatedItems)));
        }, FAKE_DELAY);
    }),

    saveApprovedOrder: (order: StockOrder, stockUpdates: StockItem[]) => new Promise<{order: StockOrder, stock: StockItem[]}>(resolve => {
         setTimeout(() => {
            // Update the order
            const orderIndex = stockOrdersDB.findIndex(o => o._id === order._id);
            if (orderIndex > -1) {
                stockOrdersDB[orderIndex] = order;
            }
            // Update the stock items
            stockUpdates.forEach(updatedItem => {
                const stockIndex = stockDB.findIndex(s => s._id === updatedItem._id);
                if (stockIndex > -1) {
                    // When allocating, status becomes Reserved until dealer confirms receipt
                    stockDB[stockIndex] = { ...updatedItem, status: StockStatus.Reserved };
                }
            });
             const updatedStockWithStatus = stockUpdates.map(s => ({ ...s, status: StockStatus.Reserved }));
            resolve({ order: JSON.parse(JSON.stringify(order)), stock: JSON.parse(JSON.stringify(updatedStockWithStatus))});
         }, FAKE_DELAY);
    }),
    
    confirmOrderReceipt: (orderId: string) => new Promise<{ order: StockOrder; stock: StockItem[] }>(resolve => {
        setTimeout(() => {
            const updatedStockItems: StockItem[] = [];
            const orderIndex = stockOrdersDB.findIndex(o => o._id === orderId);
            if (orderIndex === -1) {
                throw new Error("Order not found");
            }
            
            const updatedOrder = { ...stockOrdersDB[orderIndex], status: OrderStatus.Delivered };
            stockOrdersDB[orderIndex] = updatedOrder;

            if (updatedOrder.allocatedStockIds) {
                stockDB = stockDB.map(item => {
                    if (updatedOrder.allocatedStockIds!.includes(item._id)) {
                        const updatedItem = { ...item, status: StockStatus.Available };
                        updatedStockItems.push(updatedItem);
                        return updatedItem;
                    }
                    return item;
                });
            }
            
            resolve({ order: JSON.parse(JSON.stringify(updatedOrder)), stock: JSON.parse(JSON.stringify(updatedStockItems)) });
        }, FAKE_DELAY);
    }),
};
